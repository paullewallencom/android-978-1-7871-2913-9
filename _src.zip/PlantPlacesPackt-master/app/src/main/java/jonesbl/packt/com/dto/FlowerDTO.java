package jonesbl.packt.com.dto;

/**
 * Created by jonesb on 1/7/2017.
 */

public class FlowerDTO  extends PlantDTO {

    @Override
    public String toString() {
        return "Flower : " + super.toString();
    }
}
