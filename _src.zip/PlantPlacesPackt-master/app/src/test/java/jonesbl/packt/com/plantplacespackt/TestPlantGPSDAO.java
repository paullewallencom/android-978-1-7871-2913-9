package jonesbl.packt.com.plantplacespackt;

import org.junit.Test;

import static junit.framework.TestCase.assertEquals;

/**
 * Created by jonesb on 1/10/2017.
 */

public class TestPlantGPSDAO {
/*
    private ISpecimenDAO specimenDAO;
    private List<SpecimenDTO> specimens;

    @Test
    public void testGPSDAO_fetchGPSReturnsResultsWithinRange() {
        givenGPSDAOInitialized();
        whenSearchForSpecimensNearCZBG();
        thenReturnSpecimensWithinRange();
    }

    private void thenReturnSpecimensWithinRange() {
        for (SpecimenDTO specimen : specimens) {
            assertEquals(39.1461, specimen.getLatitude(), 0.2);
            assertEquals(-84.50826, specimen.getLongitute(), 0.2);
        }
    }

    private void whenSearchForSpecimensNearCZBG() {
        specimens = specimenDAO.fetchSpecimens(39.1461, -84.50826)
    }

    private void givenGPSDAOInitialized() {
        specimenDAO = new SpecimenDAO();
    }
*/
}
